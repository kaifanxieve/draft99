# Black-Box Separation Apparatus

**Author:** Kaifan XIE

---

## Overview

This repository contains a fully specified **theoretical apparatus** designed to
exhibit structural separations between four notions that are often implicitly
identified in scientific and philosophical reasoning:

- formal proof,
- physical or operational measurement,
- epistemic justification (knowledge),
- and engineering implementability.

The apparatus is formulated as an interactive black-box oracle system with
explicitly constrained admissible queries and a public interaction history.
All results arise solely from the formal interaction rules of the system.

No interpretation of author intention, psychological motivation, or normative
position is part of the apparatus.

---

## Purpose and Intended Use

This package is intended as a **theoretical reference apparatus**, suitable for:

- formal and comparative analysis,
- independent verification and reproduction,
- controlled extensions via explicit rule relaxation,
- cross-disciplinary use in logic, theoretical computer science,
  philosophy of science, and systems engineering.

It is **not** intended as:

- a psychological or behavioral experiment,
- an empirical study,
- an artistic or conceptual installation,
- or a normative or policy-oriented framework.

---

## Package Structure

The repository contains:

- `main.tex` — complete LaTeX source of the apparatus (compile-ready);
- `sections/` — modular specification including definitions, theorems,
  counterexample analysis, and structural remarks;
- `Appendix A` — a minimal relaxation map identifying which constraints
  are responsible for each separation result;
- `refs.bib` — bibliographic references to foundational frameworks
  related to the apparatus.

The entire package is designed to be uploaded as a ZIP archive to Zenodo
and assigned a DOI for persistent citation.

---

## Reproducibility

All rules, definitions, and separation results are explicitly stated.
No hidden assumptions or author-specific interpretations are required.

Researchers may freely reproduce the interaction structure, verify the
separation theorems, or construct controlled variants by modifying
individual admissibility constraints.

---

## License

This work is licensed under the  
**Creative Commons Attribution–NonCommercial–ShareAlike 4.0 International License**.

You are free to:

- **Share** — copy and redistribute the material in any medium or format;
- **Adapt** — remix, transform, and build upon the material.

Under the following terms:

- **Attribution** — appropriate credit must be given to the author;
- **NonCommercial** — the material may not be used for commercial purposes;
- **ShareAlike** — adaptations must be distributed under the same license.

License text:  
https://creativecommons.org/licenses/by-nc-sa/4.0/

---

## Compilation

The LaTeX source can be compiled using standard tools:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex