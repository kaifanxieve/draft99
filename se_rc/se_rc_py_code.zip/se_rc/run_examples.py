import matplotlib.pyplot as plt

from src.se_rc_core import run, estimate_lyapunov_max
from src.configs import cfg_1d, cfg_2d, cfg_3d, cfg_4d


def plot_basic(out, title_prefix: str):
    t = out["t"]

    # q plots
    plt.figure()
    for k in sorted([k for k in out.keys() if k.startswith("q_")]):
        plt.plot(t, out[k], label=k)
    plt.title(f"{title_prefix} / q(t)")
    plt.xlabel("t")
    plt.ylabel("q")
    plt.legend()
    plt.show()

    # param plots
    plt.figure()
    for k in sorted([k for k in out.keys() if k.startswith("p_")]):
        plt.plot(t, out[k], label=k)
    plt.title(f"{title_prefix} / params(t)")
    plt.xlabel("t")
    plt.ylabel("value")
    plt.legend()
    plt.show()

    # repairs
    print(title_prefix, "repairs_total =", int(out["repair"].sum()))


def main():
    for name, cfg in [
        ("1D", cfg_1d(2026)),
        ("2D", cfg_2d(2026)),
        ("3D", cfg_3d(2026)),
        ("4D", cfg_4d(2026)),
    ]:
        out = run(cfg)
        plot_basic(out, name)

        if name in ("3D",):
            le = estimate_lyapunov_max(cfg, eps=1e-6, fit_range=(200, 900))
            print(name, "lyapunov_max_est =", le)


if __name__ == "__main__":
    main()
