import numpy as np
import pandas as pd

from src.se_rc_core import run, estimate_lyapunov_max
from src.configs import cfg_3d, cfg_4d


def summarize(out, cfg, label: str):
    T = len(out["t"])
    tail = slice(T * 2 // 3, T)

    # parameter saturation
    sat = {}
    for pname, spec in cfg.params.items():
        p = out[f"p_{pname}"][tail]
        sat[pname] = float(
            ((np.abs(p - spec.lo) < 1e-6) | (np.abs(p - spec.hi) < 1e-6)).mean()
        )

    # tail variance
    var = {pname: float(np.var(out[f"p_{pname}"][tail])) for pname in cfg.params}

    repairs = int(out["repair"].sum())

    return {
        "case": label,
        "repairs_total": repairs,
        "sat_mean": float(np.mean(list(sat.values()))),
        "sat_max": float(np.max(list(sat.values()))),
        "tail_var_mean": float(np.mean(list(var.values()))),
    }


def falsify_no_clip():
    cfg = cfg_4d(seed=2026)
    cfg.enable_clip = False   # BREAK ASSUMPTION
    out = run(cfg)
    return summarize(out, cfg, "F1_no_clip")


def falsify_positive_feedback():
    cfg = cfg_4d(seed=2026)

    # invert repair direction = positive feedback
    def bad_repair_step(params, qs, cfg):
        newp = dict(params)
        for qname, (band, _fn) in cfg.q_defs.items():
            d = band.out_of_db(qs[qname])
            if d == 0:
                continue
            pname = cfg.repair_map[qname]
            step = cfg.params[pname].step
            # POSITIVE feedback: same sign pushes further out
            newp[pname] += (-d * step)
        if cfg.enable_clip:
            for pname, spec in cfg.params.items():
                newp[pname] = np.clip(newp[pname], spec.lo, spec.hi)
        return newp, True

    # monkey-patch for this run
    import src.se_rc_core as core
    old = core.repair_step
    core.repair_step = bad_repair_step

    out = run(cfg)
    core.repair_step = old

    return summarize(out, cfg, "F2_positive_feedback")


def falsify_inband_drift():
    cfg = cfg_4d(seed=2026)
    cfg.drift_when_inband = True   # BREAK ASSUMPTION
    cfg.drift_scale = 0.01
    out = run(cfg)
    return summarize(out, cfg, "F3_inband_drift")


def falsify_external_objective():
    cfg = cfg_3d(seed=2026)

    # inject a target on q1: push toward fixed 0.18 even if in-band
    target = 0.18
    alpha = 0.05

    def objective_repair(params, qs, cfg):
        newp = dict(params)
        # objective-driven update (violates definition)
        error = qs["q1"] - target
        newp["theta"] += alpha * error
        if cfg.enable_clip:
            for pname, spec in cfg.params.items():
                newp[pname] = np.clip(newp[pname], spec.lo, spec.hi)
        return newp, True

    import src.se_rc_core as core
    old = core.repair_step
    core.repair_step = objective_repair

    out = run(cfg)
    le = estimate_lyapunov_max(cfg, eps=1e-6, fit_range=(200, 900))
    core.repair_step = old

    s = summarize(out, cfg, "F4_external_objective")
    s["lyap_est"] = le
    return s


def main():
    rows = []
    rows.append(falsify_no_clip())
    rows.append(falsify_positive_feedback())
    rows.append(falsify_inband_drift())
    rows.append(falsify_external_objective())

    df = pd.DataFrame(rows)
    print("\n=== Falsification results ===")
    print(df.to_string(index=False))

    df.to_csv("falsification_results.csv", index=False)
    print("\nSaved: falsification_results.csv")


if __name__ == "__main__":
    main()
