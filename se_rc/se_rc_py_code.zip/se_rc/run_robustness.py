import itertools
from dataclasses import asdict
from typing import Dict, Tuple, List

import numpy as np
import pandas as pd

from src.se_rc_core import run, estimate_lyapunov_max
from src.configs import cfg_1d, cfg_2d, cfg_3d, cfg_4d


def inband_rate(out: Dict[str, np.ndarray], bands: Dict[str, Tuple[float, float]]) -> float:
    """
    bands: qname -> (lo_db, hi_db)
    rate = mean over q's of fraction of timesteps within [lo_db, hi_db]
    """
    rates = []
    for qname, (lo, hi) in bands.items():
        q = out[f"q_{qname}"]
        rates.append(float(((q >= lo) & (q <= hi)).mean()))
    return float(np.mean(rates)) if rates else 0.0


def saturation_metrics(out: Dict[str, np.ndarray], params_bounds: Dict[str, Tuple[float, float]]) -> Tuple[float, float]:
    """
    Returns:
      sat_frac: average fraction of time params are at/near bounds (last third of run)
      tail_var: average variance of params in last third (low var suggests freezing)
    """
    T = len(out["t"])
    a = T * 2 // 3
    sat_fracs = []
    tail_vars = []

    for pname, (lo, hi) in params_bounds.items():
        p = out[f"p_{pname}"][a:]
        eps = 1e-6
        at_bound = ((np.abs(p - lo) < eps) | (np.abs(p - hi) < eps)).mean()
        sat_fracs.append(float(at_bound))
        tail_vars.append(float(np.var(p)))

    return float(np.mean(sat_fracs)), float(np.mean(tail_vars))


def rough_structure_class(dim: int, le: float, sat_frac: float, tail_var: float) -> str:
    """
    Extremely cold classification, only for robustness reporting.
    """
    if dim <= 1:
        return "1D_reflection"
    if dim == 2:
        # we don't detect a limit cycle rigorously; use low saturation + boundedness assumed
        return "2D_cycle_like"
    if dim == 3:
        if abs(le) < 1e-3:
            return "3D_edge"
        if le > 1e-3:
            return "3D_chaotic_like"
        return "3D_contracting"
    # dim >= 4
    # if saturation is high or tail variance is very low => dimension collapse
    if sat_frac > 0.2 or tail_var < 1e-4:
        return "4Dplus_dim_collapse"
    return "4Dplus_high_constraint"


def make_bands_from_cfg(cfg) -> Dict[str, Tuple[float, float]]:
    bands = {}
    for qname, (band, _fn) in cfg.q_defs.items():
        bands[qname] = (band.lo_db, band.hi_db)
    return bands


def make_param_bounds(cfg) -> Dict[str, Tuple[float, float]]:
    bounds = {}
    for pname, spec in cfg.params.items():
        bounds[pname] = (spec.lo, spec.hi)
    return bounds


def tweak_cfg(cfg, window=None, deadband_scale=None, step_scale=None, seed=None):
    if seed is not None:
        cfg.seed = seed
    if window is not None:
        cfg.window = int(window)

    if deadband_scale is not None:
        # scale all deadbands
        for qname in cfg.q_defs:
            band, fn = cfg.q_defs[qname]
            band.deadband = float(band.deadband * deadband_scale)
            cfg.q_defs[qname] = (band, fn)

    if step_scale is not None:
        for pname, spec in cfg.params.items():
            spec.step = float(spec.step * step_scale)
            cfg.params[pname] = spec

    return cfg


def run_one(dim_label: str, cfg, seed: int, window: int, deadband_scale: float, step_scale: float) -> Dict:
    cfg = tweak_cfg(cfg, seed=seed, window=window, deadband_scale=deadband_scale, step_scale=step_scale)

    out = run(cfg)

    bands = make_bands_from_cfg(cfg)
    bounds = make_param_bounds(cfg)

    inb = inband_rate(out, bands)
    sat_frac, tail_var = saturation_metrics(out, bounds)

    le = np.nan
    if dim_label == "3D":
        le = estimate_lyapunov_max(cfg, eps=1e-6, fit_range=(200, 900))

    dim = int(dim_label[0])  # "1D"->1 etc
    cls = rough_structure_class(dim, le if not np.isnan(le) else 0.0, sat_frac, tail_var)

    repairs_total = int(out["repair"].sum())

    return {
        "dim": dim_label,
        "seed": seed,
        "window": window,
        "deadband_scale": deadband_scale,
        "step_scale": step_scale,
        "inband_rate_mean": inb,
        "sat_frac_tail_mean": sat_frac,
        "param_tail_var_mean": tail_var,
        "repairs_total": repairs_total,
        "lyap_est": le,
        "class": cls,
    }


def main():
    # sweep ranges (tight but informative)
    seeds = [7, 77, 777]
    windows = [60, 100, 160]
    deadband_scales = [0.5, 1.0, 1.5]
    step_scales = [0.7, 1.0, 1.3]

    configs = {
        "1D": cfg_1d(),
        "2D": cfg_2d(),
        "3D": cfg_3d(),
        "4D": cfg_4d(),
    }

    rows: List[Dict] = []

    grid = list(itertools.product(seeds, windows, deadband_scales, step_scales))

    for dim_label, base_cfg in configs.items():
        for seed, window, dbs, sps in grid:
            # rebuild cfg each time to avoid mutation accumulation
            cfg_builder = {"1D": cfg_1d, "2D": cfg_2d, "3D": cfg_3d, "4D": cfg_4d}[dim_label]
            cfg = cfg_builder(seed=seed)
            rows.append(run_one(dim_label, cfg, seed, window, dbs, sps))

    df = pd.DataFrame(rows)

    # aggregate: how often class remains the expected one
    expected = {"1D": "1D_reflection", "2D": "2D_cycle_like", "3D": "3D_edge", "4D": "4Dplus_dim_collapse"}
    df["expected_class"] = df["dim"].map(expected)
    df["class_ok"] = (df["class"] == df["expected_class"]).astype(int)

    summary = (
        df.groupby("dim")
          .agg(
              runs=("class_ok", "count"),
              class_ok_rate=("class_ok", "mean"),
              inband_mean=("inband_rate_mean", "mean"),
              inband_min=("inband_rate_mean", "min"),
              sat_mean=("sat_frac_tail_mean", "mean"),
              sat_max=("sat_frac_tail_mean", "max"),
              repairs_mean=("repairs_total", "mean"),
          )
          .reset_index()
    )

    print("\n=== Robustness summary ===")
    print(summary.to_string(index=False))

    df.to_csv("robustness_grid.csv", index=False)
    summary.to_csv("robustness_summary.csv", index=False)
    print("\nSaved: robustness_grid.csv, robustness_summary.csv")


if __name__ == "__main__":
    main()
