from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import numpy as np


def clip(x: float, lo: float, hi: float) -> float:
    return float(np.clip(x, lo, hi))


def binary_entropy(p: float) -> float:
    p = float(np.clip(p, 1e-6, 1 - 1e-6))
    return float(-(p * np.log2(p) + (1 - p) * np.log2(1 - p)))


@dataclass
class Band:
    lo: float
    hi: float
    deadband: float = 0.0

    @property
    def lo_db(self) -> float:
        return self.lo - self.deadband

    @property
    def hi_db(self) -> float:
        return self.hi + self.deadband

    def out_of_db(self, x: float) -> int:
        """
        returns:
          -1 if x < lo_db
           0 if lo_db <= x <= hi_db
          +1 if x > hi_db
        """
        if x < self.lo_db:
            return -1
        if x > self.hi_db:
            return +1
        return 0


@dataclass
class ParamSpec:
    lo: float
    hi: float
    step: float


@dataclass
class SErcConfig:
    # time
    T: int = 1500
    window: int = 100

    # signal generation
    seed: int = 2026
    signal_rho: float = 0.996
    signal_sigma: float = 0.02
    sin_amp: float = 0.0015
    sin_period: float = 250.0
    tanh_amp: float = 0.0008
    noise_scale: float = 0.25

    # trigger affine model
    # trigger if (signal + noise + affine(params)) > theta
    # theta is treated specially as the threshold
    trigger_phi_weight: float = 0.5
    trigger_psi_weight: float = 0.3

    # parameters
    params: Dict[str, ParamSpec] = None  # filled by configs

    # consistency variables: name -> (band, function(recent, q1, extras)->value)
    q_defs: Dict[str, Tuple[Band, Callable[..., float]]] = None

    # mapping: q_name -> param_name to repair
    repair_map: Dict[str, str] = None

    # initial parameter values
    init_params: Dict[str, float] = None

    # hard clip on/off (for falsification)
    enable_clip: bool = True

    # allow drift even if in-band (for falsification)
    drift_when_inband: bool = False
    drift_scale: float = 0.0


def gen_signal(cfg: SErcConfig, rng: np.random.Generator) -> np.ndarray:
    sig = np.zeros(cfg.T, dtype=float)
    for t in range(1, cfg.T):
        sig[t] = (
            cfg.signal_rho * sig[t - 1]
            + cfg.signal_sigma * rng.normal()
            + cfg.sin_amp * np.sin(2 * np.pi * t / cfg.sin_period)
            + cfg.tanh_amp * np.tanh(sig[t - 1])
        )
    return sig


def compute_qs(
    recent: np.ndarray,
    cfg: SErcConfig,
    cache: Dict[str, float],
) -> Dict[str, float]:
    # Precompute q1 to allow reuse
    q1 = float(recent.mean()) if recent.size else 0.0
    cache["q1"] = q1

    out: Dict[str, float] = {}
    for qname, (_band, fn) in cfg.q_defs.items():
        out[qname] = float(fn(recent=recent, q1=q1, cache=cache))
    return out


def repair_step(
    params: Dict[str, float],
    qs: Dict[str, float],
    cfg: SErcConfig,
) -> Tuple[Dict[str, float], bool]:
    """
    Negative feedback repair:
    - Each q_i is assigned to one parameter theta_j via cfg.repair_map
    - If q out of deadband range, push the mapped parameter by +/- step
    """
    changed = False
    newp = dict(params)

    for qname, (band, _fn) in cfg.q_defs.items():
        direction = band.out_of_db(qs[qname])
        if direction == 0:
            continue

        p_name = cfg.repair_map[qname]
        step = cfg.params[p_name].step

        # direction +1 means q too high => push parameter "up" (harder)
        # direction -1 means q too low  => push parameter "down" (easier)
        newp[p_name] = newp[p_name] + (direction * step)
        changed = True

    # optional drift even when inband (used for falsification tests)
    if cfg.drift_when_inband and cfg.drift_scale > 0.0:
        for p_name in newp:
            newp[p_name] += cfg.drift_scale

    # hard clip
    if cfg.enable_clip:
        for p_name, spec in cfg.params.items():
            newp[p_name] = clip(newp[p_name], spec.lo, spec.hi)

    return newp, changed


def run(cfg: SErcConfig) -> Dict[str, np.ndarray]:
    assert cfg.params and cfg.q_defs and cfg.repair_map and cfg.init_params

    rng = np.random.default_rng(cfg.seed)
    signal = gen_signal(cfg, rng)

    params = dict(cfg.init_params)

    trigger = np.zeros(cfg.T, dtype=int)
    repairs = np.zeros(cfg.T, dtype=int)

    # histories
    p_hist = {k: np.zeros(cfg.T, dtype=float) for k in params.keys()}
    q_hist = {k: np.zeros(cfg.T, dtype=float) for k in cfg.q_defs.keys()}

    # main loop
    for t in range(cfg.T):
        noise = cfg.noise_scale * rng.normal()

        theta = params.get("theta", 0.0)
        eta = params.get("eta", 0.0)
        phi = params.get("phi", 0.0)
        psi = params.get("psi", 0.0)

        drive = (
            signal[t]
            + noise
            + eta
            + cfg.trigger_phi_weight * phi
            + cfg.trigger_psi_weight * psi
        )
        trigger[t] = int(drive > theta)

        start = max(0, t - cfg.window + 1)
        recent = trigger[start : t + 1]

        cache: Dict[str, float] = {}
        qs = compute_qs(recent, cfg, cache)

        # record q
        for qname in q_hist:
            q_hist[qname][t] = qs[qname]

        # repair if any q is out of deadband
        new_params, changed = repair_step(params, qs, cfg)
        if changed:
            repairs[t] = 1
        params = new_params

        # record params
        for pname in p_hist:
            p_hist[pname][t] = params[pname]

    # pack
    out: Dict[str, np.ndarray] = {
        "t": np.arange(cfg.T, dtype=int),
        "signal": signal,
        "trigger": trigger,
        "repair": repairs,
    }
    out.update({f"p_{k}": v for k, v in p_hist.items()})
    out.update({f"q_{k}": v for k, v in q_hist.items()})
    return out


def estimate_lyapunov_max(
    cfg: SErcConfig,
    eps: float = 1e-6,
    fit_range: Tuple[int, int] = (200, 900),
) -> float:
    """
    Simple two-trajectory estimate on parameter time series:
    run baseline and perturbed init_params (+eps on all params)
    and fit slope of log distance in the mid range.

    Note: With hard clip + deadband, you often get ~0 by construction.
    This is for verification of the "edge" claim, not a universal LE tool.
    """
    base = SErcConfig(**{**cfg.__dict__})
    pert = SErcConfig(**{**cfg.__dict__})

    pert_init = dict(cfg.init_params)
    for k in pert_init:
        pert_init[k] = pert_init[k] + eps
    pert.init_params = pert_init

    A = run(base)
    B = run(pert)

    # distance in parameter space
    p_names = [k for k in cfg.init_params.keys()]
    PA = np.vstack([A[f"p_{k}"] for k in p_names]).T
    PB = np.vstack([B[f"p_{k}"] for k in p_names]).T

    dist = np.linalg.norm(PB - PA, axis=1)
    dist = np.maximum(dist, 1e-12)
    logd = np.log(dist)

    a, b = fit_range
    t = np.arange(len(logd), dtype=float)
    coef = np.polyfit(t[a:b], logd[a:b], 1)
    return float(coef[0])
