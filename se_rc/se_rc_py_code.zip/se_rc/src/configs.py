from __future__ import annotations

from typing import Dict, Tuple
import numpy as np

from .se_rc_core import SErcConfig, ParamSpec, Band, binary_entropy


def q_rate(recent, q1, cache) -> float:
    return q1


def q_var(recent, q1, cache) -> float:
    return float(np.var(recent)) if recent.size else 0.0


def q_autocorr1(recent, q1, cache) -> float:
    if recent.size < 3:
        return 0.0
    x = recent[:-1] - recent[:-1].mean()
    y = recent[1:] - recent[1:].mean()
    denom = float(np.sqrt((x * x).sum() * (y * y).sum()))
    return float((x * y).sum() / denom) if denom > 0 else 0.0


def q_entropy(recent, q1, cache) -> float:
    # uses q1 only (binary entropy proxy)
    return binary_entropy(q1)


def base_params_1d() -> Dict[str, ParamSpec]:
    return {
        "theta": ParamSpec(lo=-2.0, hi=2.0, step=0.04),
        "eta":   ParamSpec(lo=-2.0, hi=2.0, step=0.00),  # not used
        "phi":   ParamSpec(lo=-2.0, hi=2.0, step=0.00),  # not used
        "psi":   ParamSpec(lo=-2.0, hi=2.0, step=0.00),  # not used
    }


def base_params_2d() -> Dict[str, ParamSpec]:
    return {
        "theta": ParamSpec(lo=-2.0, hi=2.0, step=0.04),
        "eta":   ParamSpec(lo=-2.0, hi=2.0, step=0.04),
        "phi":   ParamSpec(lo=-2.0, hi=2.0, step=0.00),
        "psi":   ParamSpec(lo=-2.0, hi=2.0, step=0.00),
    }


def base_params_3d() -> Dict[str, ParamSpec]:
    return {
        "theta": ParamSpec(lo=-2.0, hi=2.0, step=0.035),
        "eta":   ParamSpec(lo=-2.0, hi=2.0, step=0.03),
        "phi":   ParamSpec(lo=-2.0, hi=2.0, step=0.03),
        "psi":   ParamSpec(lo=-2.0, hi=2.0, step=0.00),
    }


def base_params_4d() -> Dict[str, ParamSpec]:
    return {
        "theta": ParamSpec(lo=-2.0, hi=2.0, step=0.03),
        "eta":   ParamSpec(lo=-2.0, hi=2.0, step=0.03),
        "phi":   ParamSpec(lo=-2.0, hi=2.0, step=0.03),
        "psi":   ParamSpec(lo=-2.0, hi=2.0, step=0.03),
    }


def cfg_1d(seed: int = 2026) -> SErcConfig:
    cfg = SErcConfig()
    cfg.seed = seed
    cfg.T = 1200
    cfg.window = 80

    cfg.params = base_params_1d()
    cfg.init_params = {"theta": 0.0, "eta": 0.0, "phi": 0.0, "psi": 0.0}

    cfg.q_defs = {
        "q1": (Band(lo=0.12, hi=0.22, deadband=0.015), q_rate),
    }
    cfg.repair_map = {"q1": "theta"}
    return cfg


def cfg_2d(seed: int = 2026) -> SErcConfig:
    cfg = SErcConfig()
    cfg.seed = seed
    cfg.T = 1400
    cfg.window = 80

    cfg.params = base_params_2d()
    cfg.init_params = {"theta": 0.0, "eta": 0.0, "phi": 0.0, "psi": 0.0}

    cfg.q_defs = {
        "q1": (Band(lo=0.12, hi=0.22, deadband=0.015), q_rate),
        "q2": (Band(lo=0.05, hi=0.18, deadband=0.02),  q_var),
    }
    cfg.repair_map = {"q1": "theta", "q2": "eta"}
    return cfg


def cfg_3d(seed: int = 2026) -> SErcConfig:
    cfg = SErcConfig()
    cfg.seed = seed
    cfg.T = 1500
    cfg.window = 100

    cfg.params = base_params_3d()
    cfg.init_params = {"theta": 0.0, "eta": 0.0, "phi": 0.0, "psi": 0.0}

    cfg.q_defs = {
        "q1": (Band(lo=0.12, hi=0.22, deadband=0.015), q_rate),
        "q2": (Band(lo=0.05, hi=0.18, deadband=0.02),  q_var),
        "q3": (Band(lo=-0.05, hi=0.15, deadband=0.02), q_autocorr1),
    }
    cfg.repair_map = {"q1": "theta", "q2": "eta", "q3": "phi"}
    return cfg


def cfg_4d(seed: int = 2026) -> SErcConfig:
    cfg = SErcConfig()
    cfg.seed = seed
    cfg.T = 2000
    cfg.window = 120

    cfg.params = base_params_4d()
    cfg.init_params = {"theta": 0.0, "eta": 0.0, "phi": 0.0, "psi": 0.0}

    cfg.q_defs = {
        "q1": (Band(lo=0.12, hi=0.22, deadband=0.015), q_rate),
        "q2": (Band(lo=0.05, hi=0.18, deadband=0.02),  q_var),
        "q3": (Band(lo=-0.05, hi=0.15, deadband=0.02), q_autocorr1),
        "q4": (Band(lo=0.45, hi=0.70, deadband=0.03),  q_entropy),
    }
    cfg.repair_map = {"q1": "theta", "q2": "eta", "q3": "phi", "q4": "psi"}
    return cfg
